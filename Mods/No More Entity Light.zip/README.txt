How to Install

1. Download the zip file and extract it.

2. Move and replace "archive0.tfa"

Glyph: 
	- C:\Program Files (x86)\Glyph\Games\Trove\Live\shadersunified\programs\fragment

Steam: 
	- C:\Program Files (x86)\Steam\steamapps\common\Trove\Games\Trove\Live\shadersunified\programs\fragment